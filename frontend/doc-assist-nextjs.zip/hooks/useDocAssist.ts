'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { QA, DOCS_INITIAL } from '@/lib/data';
import { BAR_COUNT, PIXELS } from '@/lib/orb';
import type { Message, HistoryGroup, Doc, VoiceStatus, ResponseStyle, QAItem } from '@/lib/types';

const INITIAL_HISTORY: HistoryGroup[] = [
  { group: 'Today', items: [QA[3]] },
  { group: 'Earlier this week', items: [QA[0], QA[1], QA[2], QA[4]] },
];

/**
 * All Doc Assist workspace state and behavior in one hook.
 *
 * TODO when wiring the real backend (see backend handoff doc):
 * - sendMessage: replace the QA-cycling + setTimeout with a call to
 *   POST /ask, streaming or awaiting the response, and populate
 *   { doc, page } from the real citation the backend returns.
 * - toggleListen: replace the two setTimeout stages with actual STT
 *   (start listening -> transcript arrives) and TTS (assistant audio
 *   starts/ends), and drive orbScale/pixelLevels/barLevels from a
 *   Web Audio AnalyserNode on the TTS playback stream instead of
 *   Math.random(). commitVoiceExchange should receive the *real*
 *   transcribed question and real answer, not a canned QAItem.
 */
export function useDocAssist() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [sourcesOpen, setSourcesOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [activeDoc, setActiveDoc] = useState<string | null>(null);
  const [activeHistoryTitle, setActiveHistoryTitle] = useState<string | null>(null);
  const [voiceStatus, setVoiceStatus] = useState<VoiceStatus>('idle');
  const [captionText, setCaptionText] = useState('');
  const [orbScale, setOrbScale] = useState(1);
  const [barLevels, setBarLevels] = useState<number[]>(Array(BAR_COUNT).fill(0.3));
  const [pixelLevels, setPixelLevels] = useState<number[]>(Array(PIXELS.length).fill(0.4));
  const [responseStyle, setResponseStyleState] = useState<ResponseStyle>('balanced');
  const [citeSources, setCiteSources] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [docs, setDocs] = useState<Doc[]>(DOCS_INITIAL);
  const [history, setHistory] = useState<HistoryGroup[]>(INITIAL_HISTORY);

  const replyCounter = useRef(0);
  const voiceTimer1 = useRef<ReturnType<typeof setTimeout>>();
  const voiceTimer2 = useRef<ReturnType<typeof setTimeout>>();
  const orbInterval = useRef<ReturnType<typeof setInterval>>();

  useEffect(() => {
    return () => {
      clearTimeout(voiceTimer1.current);
      clearTimeout(voiceTimer2.current);
      clearInterval(orbInterval.current);
    };
  }, []);

  const stopOrbAnim = useCallback(() => {
    clearInterval(orbInterval.current);
    orbInterval.current = undefined;
  }, []);

  const startOrbAnim = useCallback(() => {
    orbInterval.current = setInterval(() => {
      setOrbScale(1.05 + Math.random() * 0.5);
      setBarLevels(Array.from({ length: BAR_COUNT }, () => Math.random()));
      setPixelLevels(Array.from({ length: PIXELS.length }, () => Math.random()));
    }, 140);
  }, []);

  const pushToHistoryIfFirst = useCallback((isFirst: boolean, qa: QAItem, questionText: string) => {
    if (!isFirst) return;
    const title = questionText.length > 42 ? questionText.slice(0, 42) + '…' : questionText;
    setActiveHistoryTitle(title);
    setHistory((h) => [
      { group: 'Today', items: [{ ...qa, title, q: questionText }, ...h[0].items] },
      ...h.slice(1),
    ]);
  }, []);

  const sendMessage = useCallback(
    (text: string) => {
      const isFirst = messages.length === 0;
      const qa = QA[replyCounter.current % QA.length];
      replyCounter.current += 1;
      setMessages((m) => [...m, { role: 'user', text }]);
      setInputText('');
      pushToHistoryIfFirst(isFirst, qa, text);
      setTimeout(() => {
        setMessages((m) => [...m, { role: 'assistant', text: qa.a, doc: qa.doc, page: qa.page }]);
      }, 700);
    },
    [messages.length, pushToHistoryIfFirst],
  );

  const onComposerSend = useCallback(() => {
    const text = inputText.trim();
    if (!text) return;
    sendMessage(text);
  }, [inputText, sendMessage]);

  const newChat = useCallback(() => {
    clearTimeout(voiceTimer1.current);
    clearTimeout(voiceTimer2.current);
    stopOrbAnim();
    setMessages([]);
    setInputText('');
    setSourcesOpen(false);
    setActiveHistoryTitle(null);
    setVoiceStatus('idle');
    setCaptionText('');
    setOrbScale(1);
  }, [stopOrbAnim]);

  const selectHistoryItem = useCallback((item: QAItem) => {
    setMessages([
      { role: 'user', text: item.q },
      { role: 'assistant', text: item.a, doc: item.doc, page: item.page },
    ]);
    setSourcesOpen(false);
    setActiveHistoryTitle(item.title);
  }, []);

  const openSource = useCallback((doc?: string) => {
    if (!doc) return;
    setSourcesOpen(true);
    setActiveDoc(doc);
  }, []);

  const toggleSources = useCallback(() => setSourcesOpen((v) => !v), []);
  const goChat = useCallback(() => setSourcesOpen(false), []);

  const commitVoiceExchange = useCallback(
    (qa: QAItem) => {
      setMessages((m) => {
        const isFirst = m.length === 0;
        if (isFirst) pushToHistoryIfFirst(true, qa, qa.q);
        return [
          ...m,
          { role: 'user', text: qa.q, viaVoice: true },
          { role: 'assistant', text: qa.a, doc: qa.doc, page: qa.page, viaVoice: true },
        ];
      });
      setVoiceStatus('idle');
      setCaptionText('');
      setOrbScale(1);
    },
    [pushToHistoryIfFirst],
  );

  // Single entry point for every mic/orb affordance (rail icon, composer mic
  // button, hero orb, docked bar, overlay orb). Idle -> starts listening.
  // Active -> interrupts and discards without committing to the thread.
  const toggleListen = useCallback(() => {
    if (voiceStatus === 'idle') {
      const qa = QA[replyCounter.current % QA.length];
      setVoiceStatus('listening');
      setCaptionText('');
      setOrbScale(1.12);
      startOrbAnim();
      voiceTimer1.current = setTimeout(() => {
        replyCounter.current += 1;
        setVoiceStatus('speaking');
        setCaptionText(qa.a);
        voiceTimer2.current = setTimeout(() => {
          stopOrbAnim();
          commitVoiceExchange(qa);
        }, 3600);
      }, 1600);
    } else {
      clearTimeout(voiceTimer1.current);
      clearTimeout(voiceTimer2.current);
      stopOrbAnim();
      setVoiceStatus('idle');
      setCaptionText('');
      setOrbScale(1);
    }
  }, [voiceStatus, startOrbAnim, stopOrbAnim, commitVoiceExchange]);

  const triggerUpload = useCallback(() => {
    setUploading((u) => {
      if (u) return u;
      setTimeout(() => {
        setDocs((d) => [{ name: 'Parental Leave Update.pdf', meta: '3 pages · Updated just now' }, ...d]);
        setUploading(false);
      }, 1300);
      return true;
    });
  }, []);

  return {
    messages,
    inputText,
    setInputText,
    sourcesOpen,
    settingsOpen,
    activeDoc,
    activeHistoryTitle,
    voiceStatus,
    captionText,
    orbScale,
    barLevels,
    pixelLevels,
    responseStyle,
    citeSources,
    uploading,
    docs,
    history,
    sendMessage,
    onComposerSend,
    newChat,
    selectHistoryItem,
    openSource,
    toggleSources,
    goChat,
    toggleListen,
    triggerUpload,
    openSettings: () => setSettingsOpen(true),
    closeSettings: () => setSettingsOpen(false),
    setResponseStyle: (v: ResponseStyle) => setResponseStyleState(v),
    toggleCite: () => setCiteSources((v) => !v),
  };
}
