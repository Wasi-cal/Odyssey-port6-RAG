import type { Config } from 'tailwindcss';

// Colors are used as raw hex via Tailwind's arbitrary-value syntax
// (e.g. bg-[#211A13]) directly at each usage site rather than as named
// theme tokens — see design_handoff/README.md for the full token table.
// This keeps every component's palette visible at the call site, which
// matters here since the source-of-truth is a design doc, not this file.
const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        serif: ['var(--font-instrument-serif)', 'serif'],
        sans: ['var(--font-manrope)', 'sans-serif'],
      },
      keyframes: {
        breathe: {
          '0%, 100%': { transform: 'scale(1)' },
          '50%': { transform: 'scale(1.05)' },
        },
        fadeInUp: {
          from: { opacity: '0', transform: 'translateY(8px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        spinHalo: {
          to: { transform: 'rotate(360deg)' },
        },
        waveIdle: {
          '0%, 100%': { transform: 'scaleY(0.55)' },
          '50%': { transform: 'scaleY(1.5)' },
        },
        pixelShimmer: {
          '0%, 100%': { opacity: '0.65' },
          '50%': { opacity: '1' },
        },
      },
      animation: {
        breathe: 'breathe 5s ease-in-out infinite',
        fadeInUp: 'fadeInUp 0.35s ease',
        fadeIn: 'fadeIn 0.3s ease',
        spinHalo: 'spinHalo 10s linear infinite',
        waveIdle: 'waveIdle 1.6s ease-in-out infinite',
        pixelShimmer: 'pixelShimmer 2.6s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};

export default config;
