export type Role = 'user' | 'assistant';

export interface Message {
  role: Role;
  text: string;
  doc?: string;
  page?: number;
  /** True when this message was produced via a voice exchange that just
   * collapsed into the thread (see hooks/useDocAssist.ts commitVoiceExchange). */
  viaVoice?: boolean;
}

export interface QAItem {
  title: string;
  q: string;
  a: string;
  doc: string;
  page: number;
}

export interface Doc {
  name: string;
  meta: string;
}

export interface HistoryGroup {
  group: string;
  items: QAItem[];
}

export type VoiceStatus = 'idle' | 'listening' | 'speaking';
export type ResponseStyle = 'concise' | 'balanced' | 'detailed';
