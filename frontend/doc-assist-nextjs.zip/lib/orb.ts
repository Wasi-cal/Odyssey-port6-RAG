export const PIX_GRID = 14;
export const BAR_COUNT = 28;

const PIX_CENTER = (PIX_GRID - 1) / 2;
const PIX_MAXDIST = Math.sqrt(2) * PIX_CENTER;

interface PixelMeta {
  dist: number;
  delay: string;
}

// 196 cells (14x14), each carrying its normalized distance from center and
// a diagonal shimmer delay. Cells beyond 0.74 normalized distance are
// masked out so the square grid reads as a circle.
export const PIXELS: PixelMeta[] = (() => {
  const arr: PixelMeta[] = [];
  for (let r = 0; r < PIX_GRID; r++) {
    for (let c = 0; c < PIX_GRID; c++) {
      const dist = Math.sqrt((r - PIX_CENTER) ** 2 + (c - PIX_CENTER) ** 2) / PIX_MAXDIST;
      arr.push({ dist, delay: `${((r + c) * 0.035).toFixed(2)}s` });
    }
  }
  return arr;
})();

export function lerpColor(hexA: string, hexB: string, t: number): string {
  const a = parseInt(hexA.slice(1), 16);
  const b = parseInt(hexB.slice(1), 16);
  const ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
  const br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
  const r = Math.round(ar + (br - ar) * t);
  const g = Math.round(ag + (bg - ag) * t);
  const bl = Math.round(ab + (bb - ab) * t);
  return `rgb(${r},${g},${bl})`;
}

export interface PixelRenderState {
  color: string;
  opacity: number;
  /** Whether this cell should run the idle shimmer keyframe. False while active/reactive. */
  animate: boolean;
  delay: string;
}

/**
 * active=false  -> idle shimmer, opacity derived purely from distance-to-center.
 * active=true   -> reactive: opacity also driven by pixelLevels[i], which
 *                  should be real Web Audio amplitude data in production
 *                  (currently randomized on a 140ms interval — see
 *                  useDocAssist's startOrbAnim).
 */
export function computePixels(active: boolean, pixelLevels: number[]): PixelRenderState[] {
  return PIXELS.map((p, i) => {
    if (p.dist > 0.74) return { color: 'transparent', opacity: 0, animate: false, delay: '0s' };
    const centerWeight = 1 - p.dist;
    const color = lerpColor('#FCEAD1', '#8A3218', p.dist);
    let opacity: number;
    if (active) {
      const lvl = pixelLevels[i] ?? 0.5;
      opacity = Math.min(1, 0.3 + centerWeight * 0.4 + lvl * centerWeight * 0.7);
    } else {
      opacity = 0.3 + centerWeight * 0.6;
    }
    return { color, opacity, animate: !active, delay: p.delay };
  });
}

export interface BarRenderState {
  transform: string;
  animate: boolean;
  delay: string;
}

export function computeBars(active: boolean, barLevels: number[]): BarRenderState[] {
  return Array.from({ length: BAR_COUNT }).map((_, i) => {
    if (active) {
      const lvl = barLevels[i] ?? 0.4;
      return { transform: `scaleY(${(0.4 + lvl * 2.6).toFixed(2)})`, animate: false, delay: '0s' };
    }
    return { transform: 'scaleY(1)', animate: true, delay: `${(i * 0.045).toFixed(3)}s` };
  });
}
