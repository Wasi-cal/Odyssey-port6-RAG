import type { QAItem, Doc } from './types';

// Placeholder content standing in for real backend responses. Replace
// sendMessage/toggleListen in hooks/useDocAssist.ts with calls to the
// FastAPI /ask endpoint (see the backend handoff doc) — this file only
// exists so the UI has something to render before that wiring happens.
export const QA: QAItem[] = [
  {
    title: 'Parental leave policy',
    q: "What's our parental leave policy?",
    a: 'Full-time employees get 12 weeks of paid parental leave, plus up to 4 additional unpaid weeks. Leave can start up to 2 weeks before the due date and must be taken within 12 months of the birth or placement.',
    doc: 'Employee Handbook 2026',
    page: 34,
  },
  {
    title: 'Expense report submission',
    q: 'How do I submit an expense report?',
    a: 'Submit expenses through the Finance portal within 30 days of purchase, attaching an itemized receipt for anything over $25. Reimbursements are processed on the next bi-weekly pay cycle.',
    doc: 'Expense Reimbursement SOP',
    page: 2,
  },
  {
    title: 'Code of Conduct update',
    q: 'When was the Code of Conduct last updated?',
    a: 'The Code of Conduct was last revised in November 2024, adding updated guidance on AI tool usage and conflicts of interest.',
    doc: 'Code of Conduct',
    page: 1,
  },
  {
    title: 'PTO after 2 years',
    q: 'How many PTO days do I get after 2 years?',
    a: 'After 2 years of tenure, PTO accrual increases from 15 to 20 days per year, plus your standard 10 company holidays.',
    doc: 'Employee Handbook 2026',
    page: 12,
  },
  {
    title: 'New hire equipment request',
    q: 'How do I request new hire equipment?',
    a: 'New hires get a laptop and starter kit automatically two days before their start date. Additional equipment can be requested via the IT portal during onboarding week.',
    doc: 'Onboarding Checklist',
    page: 3,
  },
];

export const DOCS_INITIAL: Doc[] = [
  { name: 'Employee Handbook 2026', meta: '58 pages · Updated Jan 2026' },
  { name: 'Remote Work Policy', meta: '6 pages · Updated Mar 2025' },
  { name: 'Expense Reimbursement SOP', meta: '9 pages · Updated Jun 2025' },
  { name: 'Onboarding Checklist', meta: '4 pages · Updated Aug 2025' },
  { name: 'Code of Conduct', meta: '11 pages · Updated Nov 2024' },
];
