# Handoff: Doc Assist — Chat + Voice Interface (Refined)

## What changed from the previous pass, and why

Two decisions were locked in before this refinement:
1. **Chat and voice are one unified surface** — the orb morphs in place, it doesn't hand off to a separate screen.
2. **Visual direction is dark, ambient, orb-forward** — not the light/cream theme the first draft shipped with.

The previous file didn't reflect either yet: it was light-themed throughout (only the icon rail was dark), and voice was a hard `mode` switch to a full-bleed screen that hid the sidebar entirely. This pass rebuilds both.

## The interaction model, concretely

There is no more `mode: 'onboarding' | 'chat' | 'voice'`. There's just **one workspace**, and the orb has three states derived from `voiceStatus` and whether a thread exists:

- **`showHero`** — no messages yet, voice idle. Large orb centered with headline, composer, suggestion chips, upload dropzone. This is the landing state.
- **`showDocked`** — messages exist, voice idle. The same orb shrinks to a 34px pill docked in a horizontal bar above the thread ("Tap to talk to Doc Assist"). Messages scroll below it. Composer stays pinned at the bottom, same position it was in during onboarding.
- **`showOverlay`** — voice is listening or speaking, regardless of whether a thread exists yet. The orb (now large again) floats centered over a scrim that dims whatever's underneath — sidebar, topbar, and sources panel all stay visible and in place. This is the only state that visually resembles the old "voice mode," but it's an overlay within the workspace, not a navigation.

Every mic/orb affordance — rail icon, composer mic button, the hero orb itself, the docked bar, the overlay orb — calls the same `toggleListen()`. Tapping while idle starts the listen→speak cycle; tapping again while active interrupts and discards it (matches the original spec's cancel behavior).

**The morph, mechanically:** when a spoken exchange finishes, `commitVoiceExchange()` fires in the same tick that resets `voiceStatus` to `idle` — it appends the user's spoken question and the assistant's spoken answer as ordinary messages (tagged `viaVoice: true`, shown with a small "Via voice" label) and collapses the orb back to its docked size. There's never a moment where voice output exists somewhere the chat thread can't see it.

One open decision worth flagging: right now `showOverlay` is a scrim + centered orb regardless of scroll position. If a thread is long, consider whether the overlay should appear anchored near the docked bar (top) instead of dead-center, so it doesn't feel disconnected from where the user was reading. Not resolved here — a fast thing to try both ways in-browser.

## Dark theme retoning

Full token pass, not just a background swap:

| Token | Old (light) | New (dark) |
|---|---|---|
| App background | `#F6F1E9` | `#15110D` |
| Sidebar / sources panel | `#FBF8F3` | `#1B1611` |
| Rail gradient | `#2A2119 → #1D1712` | `#120D09 → #0C0906` (now darker than app bg, kept as the one deliberately separated layer) |
| Card / composer / assistant bubble | `#FFFFFF` | `#211A13` |
| Hairline border | `#E7DFD2` | `#362B20` |
| Primary text | `#2A2420` | `#F3E8DA` |
| Secondary text | `#5A5044` | `#B9AA9A` / `#C9BCA9` |
| Muted text | `#8A8073` / `#948A7D` / `#B4A996` | `#8A7B68` / `#7A6E5C` / `#6E6252` |
| Citation chip | bg `#FBF8F3`, border `#E7DFD2` | bg `#221B14`, border `#362B20` |
| Citation active tint | `#F0E4D2` / `#DDBB8E` | `#2E2318` / `#4A3421` |
| Mic icon bg/color | `#F6F1E9` / `#8A5A2E` | `#2A2015` / `#E8A15C` (brightened so it still reads on dark) |
| Avatar bg/text | `#EFE2CC` / `#8A5A2E` | `#2E2318` / `#E8A15C` |
| Shadows | soft warm-grey (`rgba(42,36,32,…)`) | true black (`rgba(0,0,0,…)`), slightly heavier alpha since dark surfaces need more shadow to read |

**Kept unchanged:** accent orange (`#C1592F`), the orb's gradient stops (`#FCEAD1 → #8A3218`), the danger/end-call red (`#B23B22`). All three already read as warm points of light against a dark field — that's the ember-against-void quality the Framer sphere reference has, and it's the reason this palette works better dark than light: the amber glow now does actual atmospheric work instead of competing with a cream background.

The halo/glow layers behind the orb (conic-gradient rotation + radial blur) are unchanged in structure, slightly bumped in opacity in the overlay state (`0.3`/`0.45` vs `0.28`/`0.4` in hero) since it's meant to feel more intense when actively listening/speaking.

## Screens / Views (updated)

### Rail (persistent, unchanged position/behavior)
Chat icon now highlights whenever the sources panel is closed (there's no separate "chat mode" to represent); Voice icon highlights whenever `voiceStatus !== 'idle'`; Documents icon highlights when the sources panel is open. Chat icon's click handler just closes the sources panel — it's a "return focus to the thread" action, not a navigation.

### Sidebar & Sources panel
Unchanged behavior. The meaningful change: **sidebar is always rendered**, full stop — it's no longer conditionally hidden for a `voice` mode that doesn't exist anymore.

### Composer
Unchanged behavior and position (always pinned bottom). New: it visually dims to 35% opacity and disables pointer events while the voice overlay is active, so it doesn't compete for attention or accept stray input mid-conversation.

### Settings modal
Retoned only — dark card, accent-filled active segmented-control state (previously used a near-black fill that doesn't read as "active" on a dark background, so the active state now uses the accent color instead).

## Design Tokens (superseding the previous file's token table)

**Colors**
- Background (app): `#15110D`
- Panel / sidebar / sources: `#1B1611`
- Card / composer / assistant bubble: `#211A13`
- Hairline border: `#362B20`
- Primary text: `#F3E8DA`
- Secondary text: `#B9AA9A` / `#C9BCA9`
- Muted text: `#8A7B68` / `#7A6E5C` / `#6E6252`
- Accent (unchanged, tweakable): `#C1592F` — alt swatches `#B8763F`, `#A8622F`, `#C68B3E`
- Mic icon bg/color: `#2A2015` / `#E8A15C`
- Citation chip: bg `#221B14`, border `#362B20`, text `#E0A868`; active tint `#2E2318` / `#4A3421`
- Rail gradient: `#120D09 → #0C0906`; rail active `#2E2318` / `#F3E8DA`; rail muted icon `#7A6E5C`
- Orb gradient stops (unchanged): `#FCEAD1 → #8A3218`
- Danger / end-call (unchanged): `#B23B22`, hover `#9A3018`
- Avatar bg `#2E2318` / avatar text `#E8A15C`

**Typography, radius, shadow shape, and motion timing are unchanged** from the original spec — only colors moved. See original values: Instrument Serif for display, Manrope for body/UI; radius scale 8/10/14–16/18/999px; hover transitions ~0.15s ease, message fade-in-up 0.35s ease, orb/halo loops 1.6s–12s.

## State Management (updated shape)

- `messages`: `{ role: 'user'|'assistant', text, doc?, page?, viaVoice? }[]`
- `voiceStatus`: `'idle' | 'listening' | 'speaking'` — this alone (plus `messages.length`) now drives which of the three orb states renders. No separate `mode` field.
- `history`, `docs`, `sourcesOpen`, `settingsOpen`, `activeDoc`, `activeHistoryTitle`, `responseStyle`, `citeSources`: unchanged from original spec.
- `captionText`, `orbScale`, `pixelLevels[196]`, `barLevels[28]`: unchanged — still placeholders for real Web Audio `AnalyserNode` amplitude data in production.

## Still open / not resolved in this pass
- Overlay anchoring on long threads (see note above).
- Real amplitude wiring for `orbScale` / `pixelLevels` / `barLevels` (both drafts have flagged this — still `Math.random()`-driven).
- Whether "Via voice" messages need any visual treatment beyond the small label (e.g., should they render in the transcript at all, or only in a collapsed "call summary" card?). Left as plain messages for now since that's what makes the morph legible.

## Files
- `Doc Assist.dc.html` — the refined interactive prototype (open directly in a browser; no build step).
