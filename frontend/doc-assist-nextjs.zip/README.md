# Doc Assist — Next.js implementation

This is a direct translation of `design_handoff_doc_assist/Doc Assist.dc.html` (the refined,
dark/unified Claude Design prototype) into real Next.js 14 App Router + TypeScript + Tailwind
components. Nothing here has been run or built — no `npm install`, no `next dev`, no
`next build` — this is source only, to be verified and iterated on with Claude Code.

## Getting it running

```
npm install
npm run dev
```

Next.js will generate `next-env.d.ts` on first run — that's expected, it's gitignored.

## Structure

```
app/
  layout.tsx        Root layout — loads Instrument Serif + Manrope via next/font/google
  page.tsx           Renders <Workspace />
  globals.css        Tailwind directives + scrollbar styling
components/
  Workspace.tsx      Top-level assembly — owns nothing itself, just wires useDocAssist()
                     into Rail / TopBar / Sidebar / Hero|Docked|Overlay / SourcesPanel / SettingsModal
  Rail.tsx           Persistent left icon rail
  TopBar.tsx          Wordmark + avatar
  Sidebar.tsx        Chat history, left drawer
  SourcesPanel.tsx   Document library, right drawer
  SettingsModal.tsx  Response style / cite-sources toggle
  Composer.tsx       Bottom-docked input, used once a thread exists
  MessageBubble.tsx  Single chat bubble incl. citation chip
  HeroEmpty.tsx      Empty-state: big orb + headline + inline composer + suggestions + upload
  DockedThread.tsx   Non-empty state: small orb bar + scrolling message list
  VoiceOverlay.tsx   Active voice state: big orb + waveform + caption, floats over everything
  Orb.tsx            The 14x14 pixel-grid orb itself, reused at 34px and ~200px
  GrainOverlay.tsx   Decorative noise texture
hooks/
  useDocAssist.ts    All state + behavior lives here. Read this first.
lib/
  types.ts           Message, QAItem, Doc, HistoryGroup, VoiceStatus, ResponseStyle
  data.ts            Placeholder QA + document data — see TODO below
  orb.ts             Pure pixel-grid math (lerpColor, computePixels, computeBars) — no React
```

## The interaction model (read this before changing anything)

There's no `mode` state. The workspace derives which of three views to show from
`voiceStatus` and `messages.length`:

- `showHero` — no messages, voice idle → `HeroEmpty`
- `showDocked` — messages exist, voice idle → `DockedThread` + bottom `Composer`
- `showOverlay` — `voiceStatus !== 'idle'` → `VoiceOverlay`, absolutely positioned over
  whichever of the two above is currently mounted, with the sidebar/rail/sources panel
  still visible and in place underneath

Every mic/orb affordance in the whole app — rail icon, composer mic button, hero orb,
docked bar, overlay orb — calls the same `toggleListen()` from `useDocAssist`. That's a
deliberate constraint: adding a *second* way to start voice should still route through it,
not duplicate its logic.

When a voice exchange finishes, `commitVoiceExchange()` appends both turns into `messages`
(tagged `viaVoice: true`) in the same state update that resets `voiceStatus` to `'idle'` —
that's the "morph": the orb collapsing and the transcript landing in the thread happen
together, not as two separate steps.

## TODO before this is real

Everything currently runs on canned data from `lib/data.ts` (`QA`, `DOCS_INITIAL`) cycled
by a counter, with `setTimeout` standing in for network latency and STT/TTS. Per the
backend handoff doc, the real wiring is:

1. **`sendMessage` in `useDocAssist.ts`** — replace the QA-cycling + `setTimeout` with a
   `POST /ask` call (confirm exact request/response shape against `backend/api.py` first,
   per the backend handoff doc — don't assume it matches `QAItem`'s shape).
2. **`toggleListen` in `useDocAssist.ts`** — replace the two-stage `setTimeout` with real
   STT (listening → transcript arrives) and TTS (speaking → assistant audio plays).
   `commitVoiceExchange` should receive the *actual* transcribed question and real answer,
   not a `QAItem` pulled from the demo array.
3. **`startOrbAnim` in `useDocAssist.ts`** — `orbScale`, `pixelLevels`, and `barLevels` are
   `Math.random()`-driven on a 140ms interval. Replace with real amplitude data from a
   Web Audio `AnalyserNode` on the TTS playback stream. `lib/orb.ts`'s `computePixels` /
   `computeBars` already take levels as plain number arrays, so the render side doesn't
   need to change — only what feeds them.
4. **Auth** — nothing here handles the JWT flow described in the backend handoff doc yet.
   This is UI-only.

## Known simplification vs. the design spec

The hero-state orb's rotating halo uses a single 10s rotation for both hero and voice-active
states; the original design doc called out 12s for hero vs. 10s for the active overlay. Not
load-bearing — bump `animate-spinHalo`'s duration in `tailwind.config.ts` or add a second
variant if the difference matters once you see it in motion.
