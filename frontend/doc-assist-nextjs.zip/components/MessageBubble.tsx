import type { Message } from '@/lib/types';

interface MessageBubbleProps {
  message: Message;
  citeSources: boolean;
  onOpenSource: (doc?: string) => void;
}

export function MessageBubble({ message, citeSources, onOpenSource }: MessageBubbleProps) {
  const isUser = message.role === 'user';
  const hasCitation = !!(message.doc && citeSources);

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className="flex max-w-[560px] flex-col gap-1.5">
        {message.viaVoice && (
          <span
            className={`text-[10px] font-bold uppercase tracking-[0.06em] text-[#6E6252] ${
              isUser ? 'self-end' : 'self-start'
            }`}
          >
            Via voice
          </span>
        )}
        <div
          className={`animate-fadeInUp rounded-2xl px-4 py-3 text-[14.5px] leading-[1.55] ${
            isUser
              ? 'rounded-br-[4px] bg-[#C1592F] text-[#FBF3E7]'
              : 'rounded-bl-[4px] border border-[#362B20] bg-[#211A13] text-[#F0E6D8]'
          }`}
        >
          {message.text}
        </div>
        {hasCitation && (
          <button
            onClick={() => onOpenSource(message.doc)}
            className="flex items-center gap-1.5 self-start rounded-lg border border-[#362B20] bg-[#221B14] px-2.5 py-1.5 text-xs text-[#E0A868] transition-colors hover:border-[#5A3F26] hover:bg-[#332619]"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <path d="M14 2v6h6" />
            </svg>
            {message.doc} · p.{message.page}
          </button>
        )}
      </div>
    </div>
  );
}
