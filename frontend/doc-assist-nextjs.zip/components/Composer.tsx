'use client';

interface ComposerProps {
  value: string;
  onChange: (v: string) => void;
  onSend: () => void;
  onMic: () => void;
  disabled?: boolean;
}

export function Composer({ value, onChange, onSend, onMic, disabled }: ComposerProps) {
  return (
    <div className="flex items-center gap-2 rounded-2xl border border-[#362B20] bg-[#211A13] py-2 pl-[18px] pr-2 shadow-[0_8px_24px_rgba(0,0,0,0.35)]">
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') onSend();
        }}
        placeholder="Message Doc Assist…"
        disabled={disabled}
        className="flex-1 bg-transparent text-[15px] text-[#F3E8DA] outline-none placeholder:text-[#7A6E5C]"
      />
      <button
        onClick={onMic}
        title="Talk instead"
        className="flex h-[38px] w-[38px] flex-shrink-0 items-center justify-center rounded-[10px] bg-[#2A2015] text-[#E8A15C] transition-colors hover:bg-[#332619]"
      >
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
          <path d="M19 10v2a7 7 0 0 1-14 0v-2M12 19v4" />
        </svg>
      </button>
      <button
        onClick={onSend}
        title="Send"
        className="flex h-[38px] w-[38px] flex-shrink-0 items-center justify-center rounded-[10px] bg-[#C1592F] text-[#FBF3E7] transition-colors hover:bg-[#A84B26]"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M22 2 11 13" />
          <path d="M22 2 15 22l-4-9-9-4 20-7z" />
        </svg>
      </button>
    </div>
  );
}
