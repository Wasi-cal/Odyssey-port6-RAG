'use client';

import { computePixels } from '@/lib/orb';

interface OrbProps {
  /** CSS size value, e.g. '34px' or 'min(200px, 24vh)'. */
  size: string;
  /** True while voiceStatus is 'listening' | 'speaking'. */
  active: boolean;
  pixelLevels: number[];
  orbScale: number;
  /** Skip the rotating halo + glow layers — used for the small docked orb. */
  showHalo?: boolean;
  onClick?: () => void;
  title?: string;
}

export function Orb({ size, active, pixelLevels, orbScale, showHalo = true, onClick, title }: OrbProps) {
  const pixels = computePixels(active, pixelLevels);

  return (
    <div
      onClick={onClick}
      title={title}
      className="relative flex items-center justify-center"
      style={{ width: size, height: size, cursor: onClick ? 'pointer' : undefined }}
    >
      {showHalo && (
        <>
          <div
            className="absolute animate-spinHalo rounded-full"
            style={{
              inset: '-28px',
              background: 'conic-gradient(from 0deg, transparent, rgba(232,161,92,0.3), transparent 55%)',
              filter: 'blur(6px)',
            }}
          />
          <div
            className="absolute rounded-full"
            style={{
              inset: '8px',
              background: 'radial-gradient(circle at 40% 35%, rgba(232,161,92,0.42), transparent 65%)',
              filter: 'blur(18px)',
            }}
          />
        </>
      )}
      <div
        className={`relative grid ${!active ? 'animate-breathe' : ''}`}
        style={{
          gridTemplateColumns: 'repeat(14, 1fr)',
          gridTemplateRows: 'repeat(14, 1fr)',
          gap: '2px',
          width: '100%',
          height: '100%',
          transform: `scale(${orbScale})`,
          transition: 'transform 0.18s ease',
        }}
      >
        {pixels.map((p, i) => (
          <div
            key={i}
            className={p.animate ? 'animate-pixelShimmer' : ''}
            style={{
              width: '100%',
              height: '100%',
              borderRadius: '2px',
              background: p.color,
              opacity: p.opacity,
              animationDelay: p.delay,
            }}
          />
        ))}
      </div>
    </div>
  );
}
