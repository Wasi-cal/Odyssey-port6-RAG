'use client';

import type { Doc } from '@/lib/types';

interface SourcesPanelProps {
  docs: Doc[];
  activeDoc: string | null;
  uploading: boolean;
  onClose: () => void;
  onUpload: () => void;
}

export function SourcesPanel({ docs, activeDoc, uploading, onClose, onUpload }: SourcesPanelProps) {
  return (
    <div className="w-[300px] flex-shrink-0 overflow-y-auto border-l border-[#241C14] bg-[#1B1611] p-[18px]">
      <div className="mb-1 flex items-center justify-between">
        <span className="text-sm font-bold text-[#F3E8DA]">Sources</span>
        <button onClick={onClose} className="p-1 text-[#8A7B68] transition-colors hover:text-[#F3E8DA]">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
        </button>
      </div>
      <div className="mb-3.5 text-xs text-[#8A7B68]">Documents referenced in this workspace</div>

      {docs.map((d) => {
        const active = d.name === activeDoc;
        return (
          <div
            key={d.name}
            className={`mb-2 flex items-start gap-2.5 rounded-[10px] border p-2.5 transition-shadow hover:shadow-[0_2px_10px_rgba(0,0,0,0.3)] ${
              active ? 'border-[#4A3421] bg-[#2E2318]' : 'border-[#362B20] bg-[#1F1912]'
            }`}
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#E0A868"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mt-0.5 flex-shrink-0"
            >
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <path d="M14 2v6h6" />
            </svg>
            <div className="min-w-0">
              <div className="truncate text-[13px] font-semibold text-[#F0E6D8]">{d.name}</div>
              <div className="mt-0.5 text-[11.5px] text-[#8A7B68]">{d.meta}</div>
            </div>
          </div>
        );
      })}

      <button
        onClick={onUpload}
        className="mt-1.5 w-full rounded-[10px] border-[1.5px] border-dashed border-[#4A3421] p-3 text-[12.5px] text-[#8A7B68] transition-colors hover:border-[#C1592F] hover:text-[#E0A868]"
      >
        {uploading ? 'Uploading…' : 'Drop a policy doc here to upload'}
      </button>
    </div>
  );
}
