interface TopBarProps {
  companyName: string;
  userInitials: string;
}

export function TopBar({ companyName, userInitials }: TopBarProps) {
  return (
    <div className="relative z-[2] flex h-16 flex-shrink-0 items-center justify-between bg-[#15110D] px-7 shadow-[0_1px_0_rgba(0,0,0,0.5)]">
      <div className="flex flex-col">
        <span className="font-serif text-[22px] leading-none tracking-[-0.01em] text-[#F3E8DA]">{companyName}</span>
        <span className="mt-0.5 text-xs text-[#8A7B68]">HR &amp; SOPs workspace</span>
      </div>
      <div className="flex h-[34px] w-[34px] items-center justify-center rounded-full bg-[#2E2318] text-[13px] font-bold text-[#E8A15C]">
        {userInitials}
      </div>
    </div>
  );
}
