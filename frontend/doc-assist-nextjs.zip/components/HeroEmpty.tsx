'use client';

import { Orb } from './Orb';
import type { QAItem } from '@/lib/types';

interface HeroEmptyProps {
  orbScale: number;
  pixelLevels: number[];
  onToggleListen: () => void;
  suggestions: QAItem[];
  onPickSuggestion: (q: string) => void;
  uploadHint: string;
  onUpload: () => void;
  inputValue: string;
  onInputChange: (v: string) => void;
  onSend: () => void;
}

export function HeroEmpty({
  orbScale,
  pixelLevels,
  onToggleListen,
  suggestions,
  onPickSuggestion,
  uploadHint,
  onUpload,
  inputValue,
  onInputChange,
  onSend,
}: HeroEmptyProps) {
  return (
    <div className="relative flex flex-1 flex-col items-center justify-center overflow-y-auto p-10">
      <div
        className="pointer-events-none absolute -top-[110px] left-1/2 h-[420px] w-[640px] -translate-x-1/2 blur-[70px]"
        style={{ background: 'radial-gradient(circle, rgba(232,161,92,0.22), transparent 70%)' }}
      />

      <div className="relative mb-[26px]">
        <Orb
          size="min(200px, 24vh)"
          active={false}
          pixelLevels={pixelLevels}
          orbScale={orbScale}
          onClick={onToggleListen}
          title="Tap to talk"
        />
      </div>

      <div className="relative max-w-[620px] text-center font-serif text-[clamp(38px,4.2vw,54px)] leading-[1.1] tracking-[-0.01em] text-[#F3E8DA]">
        Ask anything about how we work.
      </div>
      <div className="relative mt-3.5 max-w-[460px] text-center text-[15px] leading-normal text-[#A79A88]">
        Doc Assist knows the handbook, SOPs, and policies — updated the moment they change.
      </div>

      <div className="relative mt-7 flex w-full max-w-[620px] items-center gap-2 rounded-2xl border border-[#362B20] bg-[#211A13] py-2 pl-[18px] pr-2 shadow-[0_8px_24px_rgba(0,0,0,0.35)]">
        <input
          value={inputValue}
          onChange={(e) => onInputChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') onSend();
          }}
          placeholder="Message Doc Assist…"
          className="flex-1 bg-transparent text-[15px] text-[#F3E8DA] outline-none placeholder:text-[#7A6E5C]"
        />
        <button
          onClick={onToggleListen}
          title="Talk instead"
          className="flex h-[38px] w-[38px] flex-shrink-0 items-center justify-center rounded-[10px] bg-[#2A2015] text-[#E8A15C] transition-colors hover:bg-[#332619]"
        >
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
            <path d="M19 10v2a7 7 0 0 1-14 0v-2M12 19v4" />
          </svg>
        </button>
        <button
          onClick={onSend}
          title="Send"
          className="flex h-[38px] w-[38px] flex-shrink-0 items-center justify-center rounded-[10px] bg-[#C1592F] text-[#FBF3E7] transition-colors hover:bg-[#A84B26]"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M22 2 11 13" />
            <path d="M22 2 15 22l-4-9-9-4 20-7z" />
          </svg>
        </button>
      </div>

      <div className="relative mt-4 flex max-w-[640px] flex-wrap justify-center gap-2">
        {suggestions.map((s) => (
          <button
            key={s.title}
            onClick={() => onPickSuggestion(s.q)}
            className="rounded-full border border-[#362B20] bg-[#1F1912] px-3.5 py-2 text-[13px] text-[#B9AA9A] transition-colors hover:border-[#4A3421] hover:bg-[#2A2015]"
          >
            {s.title}
          </button>
        ))}
      </div>

      <button
        onClick={onUpload}
        className="relative mt-6 flex w-full max-w-[620px] items-center justify-center gap-2 rounded-2xl border-[1.5px] border-dashed border-[#4A3421] p-4 text-[13px] text-[#8A7B68] transition-colors hover:border-[#C1592F] hover:text-[#E0A868]"
      >
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <path d="M17 8l-5-5-5 5M12 3v12" />
        </svg>
        <span>{uploadHint}</span>
      </button>
    </div>
  );
}
