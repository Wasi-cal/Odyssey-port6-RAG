'use client';

import { Orb } from './Orb';
import { MessageBubble } from './MessageBubble';
import type { Message } from '@/lib/types';

interface DockedThreadProps {
  orbScale: number;
  pixelLevels: number[];
  onToggleListen: () => void;
  messages: Message[];
  citeSources: boolean;
  onOpenSource: (doc?: string) => void;
}

export function DockedThread({
  orbScale,
  pixelLevels,
  onToggleListen,
  messages,
  citeSources,
  onOpenSource,
}: DockedThreadProps) {
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <button
        onClick={onToggleListen}
        title="Tap to talk"
        className="flex flex-shrink-0 items-center gap-3 border-b border-[#241C14] bg-[#1B1611] px-8 py-3 text-left transition-colors hover:bg-[#211A13]"
      >
        <Orb size="34px" active={false} pixelLevels={pixelLevels} orbScale={orbScale} showHalo={false} />
        <span className="text-[13px] font-semibold text-[#B9AA9A]">Tap to talk to Doc Assist</span>
      </button>

      <div className="flex flex-1 flex-col gap-4 overflow-y-auto px-8 py-6">
        {messages.map((m, i) => (
          <MessageBubble key={i} message={m} citeSources={citeSources} onOpenSource={onOpenSource} />
        ))}
      </div>
    </div>
  );
}
