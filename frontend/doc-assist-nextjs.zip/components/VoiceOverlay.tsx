'use client';

import { Orb } from './Orb';
import { computeBars } from '@/lib/orb';
import type { VoiceStatus } from '@/lib/types';

interface VoiceOverlayProps {
  voiceStatus: VoiceStatus;
  orbScale: number;
  pixelLevels: number[];
  barLevels: number[];
  captionText: string;
  onToggleListen: () => void;
}

export function VoiceOverlay({
  voiceStatus,
  orbScale,
  pixelLevels,
  barLevels,
  captionText,
  onToggleListen,
}: VoiceOverlayProps) {
  const active = voiceStatus !== 'idle';
  const bars = computeBars(active, barLevels);
  const statusLabel =
    voiceStatus === 'idle' ? 'Tap to talk' : voiceStatus === 'listening' ? 'Listening…' : 'Doc Assist is speaking';

  return (
    <div className="absolute inset-0 z-[5] flex animate-fadeIn flex-col items-center justify-center bg-[rgba(21,17,13,0.88)] backdrop-blur-md">
      <Orb
        size="min(200px, 24vh)"
        active={active}
        pixelLevels={pixelLevels}
        orbScale={orbScale}
        onClick={onToggleListen}
        title="Tap to interrupt"
      />

      <div className="mt-5 flex h-[52px] items-end gap-1">
        {bars.map((bar, i) => (
          <div
            key={i}
            className={`w-1 origin-bottom rounded-[3px] ${bar.animate ? 'animate-waveIdle' : ''}`}
            style={{
              height: '14px',
              transform: bar.transform,
              animationDelay: bar.delay,
              background: 'linear-gradient(180deg, #E8A15C, #C1592F)',
            }}
          />
        ))}
      </div>

      <div className="mt-3.5 text-[15px] font-semibold text-[#C9BCA9]">{statusLabel}</div>
      <div
        className="mt-2.5 max-w-[520px] px-6 text-center text-[15px] leading-normal text-[#F0E6D8] transition-opacity duration-300"
        style={{ minHeight: '44px', opacity: captionText ? 1 : 0 }}
      >
        {captionText}
      </div>

      <button
        onClick={onToggleListen}
        title="Cancel"
        className="mt-6 flex h-11 w-11 items-center justify-center rounded-full border border-[#362B20] bg-[#1F1912] text-[#B9AA9A] transition-colors hover:bg-[#271F16]"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <path d="M18 6 6 18M6 6l12 12" />
        </svg>
      </button>
    </div>
  );
}
