'use client';

import { useDocAssist } from '@/hooks/useDocAssist';
import { QA } from '@/lib/data';
import { Rail } from './Rail';
import { TopBar } from './TopBar';
import { Sidebar } from './Sidebar';
import { SourcesPanel } from './SourcesPanel';
import { SettingsModal } from './SettingsModal';
import { Composer } from './Composer';
import { HeroEmpty } from './HeroEmpty';
import { DockedThread } from './DockedThread';
import { VoiceOverlay } from './VoiceOverlay';
import { GrainOverlay } from './GrainOverlay';

export function Workspace() {
  const d = useDocAssist();

  const voiceActive = d.voiceStatus !== 'idle';
  const hasMessages = d.messages.length > 0;
  // Three mutually exclusive states of the same surface — see
  // hooks/useDocAssist.ts and design_handoff/README.md for the model.
  const showHero = !hasMessages && !voiceActive;
  const showDocked = hasMessages && !voiceActive;
  const showOverlay = voiceActive;

  return (
    <div className="relative flex h-screen w-full overflow-hidden bg-[#15110D] font-sans text-[#F3E8DA]">
      <GrainOverlay />

      <Rail
        sourcesOpen={d.sourcesOpen}
        voiceActive={voiceActive}
        onNewChat={d.newChat}
        onChatClick={d.goChat}
        onVoiceClick={d.toggleListen}
        onSourcesClick={d.toggleSources}
        onSettingsClick={d.openSettings}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar companyName="Doc Assist" userInitials="JT" />

        <div className="relative flex min-h-0 flex-1">
          <Sidebar
            history={d.history}
            activeHistoryTitle={d.activeHistoryTitle}
            onNewChat={d.newChat}
            onSelect={d.selectHistoryItem}
          />

          <div className="relative flex min-w-0 flex-1 flex-col">
            <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
              {showHero && (
                <HeroEmpty
                  orbScale={d.orbScale}
                  pixelLevels={d.pixelLevels}
                  onToggleListen={d.toggleListen}
                  suggestions={QA.slice(0, 4)}
                  onPickSuggestion={d.sendMessage}
                  uploadHint={d.uploading ? 'Uploading…' : 'Drop a policy doc here to upload'}
                  onUpload={d.triggerUpload}
                  inputValue={d.inputText}
                  onInputChange={d.setInputText}
                  onSend={d.onComposerSend}
                />
              )}

              {showDocked && (
                <DockedThread
                  orbScale={d.orbScale}
                  pixelLevels={d.pixelLevels}
                  onToggleListen={d.toggleListen}
                  messages={d.messages}
                  citeSources={d.citeSources}
                  onOpenSource={d.openSource}
                />
              )}

              {/* Floats over whichever state is underneath — never a screen swap. */}
              {showOverlay && (
                <VoiceOverlay
                  voiceStatus={d.voiceStatus}
                  orbScale={d.orbScale}
                  pixelLevels={d.pixelLevels}
                  barLevels={d.barLevels}
                  captionText={d.captionText}
                  onToggleListen={d.toggleListen}
                />
              )}
            </div>

            {/* Hero has its own inline composer; this one only appears once a thread exists. */}
            {showDocked && (
              <div
                className="flex-shrink-0 px-8 pb-6 pt-4 transition-opacity duration-200"
                style={{ opacity: voiceActive ? 0.35 : 1, pointerEvents: voiceActive ? 'none' : 'auto' }}
              >
                <Composer
                  value={d.inputText}
                  onChange={d.setInputText}
                  onSend={d.onComposerSend}
                  onMic={d.toggleListen}
                  disabled={voiceActive}
                />
              </div>
            )}
          </div>

          {d.sourcesOpen && (
            <SourcesPanel
              docs={d.docs}
              activeDoc={d.activeDoc}
              uploading={d.uploading}
              onClose={d.toggleSources}
              onUpload={d.triggerUpload}
            />
          )}
        </div>
      </div>

      <SettingsModal
        open={d.settingsOpen}
        responseStyle={d.responseStyle}
        citeSources={d.citeSources}
        onClose={d.closeSettings}
        onStyleChange={d.setResponseStyle}
        onToggleCite={d.toggleCite}
      />
    </div>
  );
}
