'use client';

import type { ResponseStyle } from '@/lib/types';

interface SettingsModalProps {
  open: boolean;
  responseStyle: ResponseStyle;
  citeSources: boolean;
  onClose: () => void;
  onStyleChange: (style: ResponseStyle) => void;
  onToggleCite: () => void;
}

const STYLES: ResponseStyle[] = ['concise', 'balanced', 'detailed'];

export function SettingsModal({
  open,
  responseStyle,
  citeSources,
  onClose,
  onStyleChange,
  onToggleCite,
}: SettingsModalProps) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#24212B]/25 backdrop-blur-sm">
      <div className="w-[420px] max-w-[90vw] rounded-[18px] border border-[#EAE6EF] bg-white p-[26px] shadow-2xl">
        <div className="mb-[18px] flex items-center justify-between">
          <span className="font-serif text-[22px] text-[#24212B]">Settings</span>
          <button onClick={onClose} className="text-[#9B96A6] hover:text-[#24212B]">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="mb-5">
          <div className="mb-2 text-[13px] font-bold text-[#24212B]">Response style</div>
          <div className="flex gap-2">
            {STYLES.map((k) => {
              const active = k === responseStyle;
              return (
                <button
                  key={k}
                  onClick={() => onStyleChange(k)}
                  className={`flex-1 rounded-[9px] border py-2.5 text-[13px] font-semibold transition-colors ${
                    active
                      ? 'border-[#8F7FE8] bg-[#8F7FE8] text-white'
                      : 'border-[#EAE6EF] bg-[#FAFAFB] text-[#6B6773]'
                  }`}
                >
                  {k[0].toUpperCase() + k.slice(1)}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center justify-between border-t border-[#F0EDF5] py-3">
          <div>
            <div className="text-[13.5px] font-semibold text-[#24212B]">Always cite sources</div>
            <div className="mt-0.5 text-xs text-[#9B96A6]">Show document references under answers</div>
          </div>
          <button
            onClick={onToggleCite}
            className={`relative h-6 w-[42px] flex-shrink-0 rounded-full transition-colors ${
              citeSources ? 'bg-[#8F7FE8]' : 'bg-[#E2DDEB]'
            }`}
          >
            <div
              className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-[0_1px_3px_rgba(0,0,0,0.25)] transition-all"
              style={{ left: citeSources ? '20px' : '2px' }}
            />
          </button>
        </div>

        <div className="flex items-center justify-between border-t border-[#F0EDF5] py-3">
          <div>
            <div className="text-[13.5px] font-semibold text-[#24212B]">Assistant voice</div>
            <div className="mt-0.5 text-xs text-[#9B96A6]">Used in voice mode</div>
          </div>
          <span className="text-[13px] font-semibold text-[#6C63B5]">Default</span>
        </div>
      </div>
    </div>
  );
}
