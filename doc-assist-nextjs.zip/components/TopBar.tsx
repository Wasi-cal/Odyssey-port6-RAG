interface TopBarProps {
  companyName: string;
  userInitials: string;
}

export function TopBar({ companyName, userInitials }: TopBarProps) {
  return (
    <div className="relative z-[2] flex h-16 flex-shrink-0 items-center justify-between border-b border-[#EAE6EF] bg-white/70 px-7 backdrop-blur-sm">
      <div className="flex flex-col">
        <span className="font-serif text-[22px] leading-none tracking-[-0.01em] text-[#24212B]">{companyName}</span>
        <span className="mt-0.5 text-xs text-[#9B96A6]">HR &amp; SOPs workspace</span>
      </div>
      <div className="flex h-[34px] w-[34px] items-center justify-center rounded-full bg-[#EDE9F5] text-[13px] font-bold text-[#6C63B5]">
        {userInitials}
      </div>
    </div>
  );
}
