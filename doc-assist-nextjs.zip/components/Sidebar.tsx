'use client';

import type { HistoryGroup, QAItem } from '@/lib/types';

interface SidebarProps {
  history: HistoryGroup[];
  activeHistoryTitle: string | null;
  onNewChat: () => void;
  onSelect: (item: QAItem) => void;
}

export function Sidebar({ history, activeHistoryTitle, onNewChat, onSelect }: SidebarProps) {
  return (
    <div className="w-[260px] flex-shrink-0 overflow-y-auto border-r border-[#EAE6EF] bg-white/60 p-3 backdrop-blur-sm">
      <button
        onClick={onNewChat}
        className="mb-3.5 flex w-full items-center gap-2 rounded-[10px] border border-[#EAE6EF] bg-white px-3 py-2.5 text-[13px] font-semibold text-[#24212B] shadow-sm transition-colors hover:bg-[#F5F1FA]"
      >
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <path d="M12 5v14M5 12h14" />
        </svg>
        New chat
      </button>

      {history.map((grp) => (
        <div key={grp.group} className="mb-4">
          <div className="px-2 pb-1.5 text-[11px] font-bold uppercase tracking-[0.06em] text-[#B4AEC0]">
            {grp.group}
          </div>
          {grp.items.map((item) => {
            const active = item.title === activeHistoryTitle;
            return (
              <button
                key={item.title}
                onClick={() => onSelect(item)}
                className={`mb-0.5 block w-full truncate rounded-lg border-l-2 px-2.5 py-2 text-left text-[13px] text-[#4A4653] transition-colors hover:bg-white ${
                  active ? 'border-[#8F7FE8] bg-[#EDE9F5]' : 'border-transparent bg-transparent'
                }`}
              >
                {item.title}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}
