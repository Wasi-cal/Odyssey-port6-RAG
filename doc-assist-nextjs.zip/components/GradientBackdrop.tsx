// Soft pink/purple blobs over a white base, matching the reference screenshot.
// Purely decorative — sits behind everything at z-0.
export function GradientBackdrop() {
  return (
    <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden bg-white">
      <div
        className="absolute -bottom-1/4 -left-1/4 h-[70vh] w-[70vh] rounded-full blur-[110px]"
        style={{ background: 'radial-gradient(circle, rgba(255,175,205,0.45), transparent 70%)' }}
      />
      <div
        className="absolute -right-1/4 top-1/4 h-[65vh] w-[65vh] rounded-full blur-[110px]"
        style={{ background: 'radial-gradient(circle, rgba(178,166,255,0.4), transparent 70%)' }}
      />
      <div
        className="absolute left-1/3 top-0 h-[45vh] w-[45vh] rounded-full blur-[100px]"
        style={{ background: 'radial-gradient(circle, rgba(255,210,225,0.3), transparent 70%)' }}
      />
    </div>
  );
}
