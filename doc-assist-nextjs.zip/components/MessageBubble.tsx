import type { Message } from '@/lib/types';

interface MessageBubbleProps {
  message: Message;
  citeSources: boolean;
  onOpenSource: (doc?: string) => void;
}

export function MessageBubble({ message, citeSources, onOpenSource }: MessageBubbleProps) {
  const isUser = message.role === 'user';
  const hasCitation = !!(message.doc && citeSources);

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex max-w-[560px] flex-col gap-1.5 ${isUser ? 'items-end' : 'items-start'}`}>
        <span className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#B4AEC0]">
          {isUser ? 'Me' : 'Our AI'}
        </span>
        <div
          className={`animate-fadeInUp rounded-2xl border px-4 py-3 text-[14.5px] leading-[1.55] shadow-sm ${
            isUser
              ? 'rounded-br-[4px] border-[#E6DFF5] bg-[#F5F1FA] text-[#24212B]'
              : 'rounded-bl-[4px] border-[#EAE6EF] bg-white text-[#24212B]'
          }`}
        >
          {message.text}
        </div>
        {hasCitation && (
          <button
            onClick={() => onOpenSource(message.doc)}
            className="flex items-center gap-1.5 rounded-lg border border-[#E4DEF0] bg-[#F5F1FA] px-2.5 py-1.5 text-xs text-[#6C63B5] transition-colors hover:border-[#D9CFF2] hover:bg-[#EDE9F5]"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <path d="M14 2v6h6" />
            </svg>
            {message.doc} · p.{message.page}
          </button>
        )}
      </div>
    </div>
  );
}
