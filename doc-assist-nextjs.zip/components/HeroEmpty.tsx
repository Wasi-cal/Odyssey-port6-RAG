'use client';

import { SparkleIcon } from './SparkleIcon';
import type { QAItem } from '@/lib/types';

interface HeroEmptyProps {
  onToggleListen: () => void;
  suggestions: QAItem[];
  onPickSuggestion: (q: string) => void;
  uploadHint: string;
  onUpload: () => void;
  inputValue: string;
  onInputChange: (v: string) => void;
  onSend: () => void;
}

export function HeroEmpty({
  onToggleListen,
  suggestions,
  onPickSuggestion,
  uploadHint,
  onUpload,
  inputValue,
  onInputChange,
  onSend,
}: HeroEmptyProps) {
  return (
    <div className="relative flex flex-1 flex-col items-center justify-center overflow-y-auto p-10">
      <SparkleIcon size={32} className="mb-5 text-[#24212B]" />

      <div className="max-w-[560px] text-center text-[32px] font-medium leading-[1.2] tracking-[-0.01em] text-[#24212B]">
        Ask anything about how we work.
      </div>
      <div className="mt-3 max-w-[420px] text-center text-[15px] leading-normal text-[#8B8794]">
        Doc Assist knows the handbook, SOPs, and policies — updated the moment they change.
      </div>

      <div className="mt-7 flex w-full max-w-[620px] items-center gap-2 rounded-2xl border border-[#EAE6EF] bg-white py-2 pl-[18px] pr-2 shadow-[0_8px_24px_rgba(140,120,200,0.12)]">
        <input
          value={inputValue}
          onChange={(e) => onInputChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') onSend();
          }}
          placeholder="Ask me anything about your projects"
          className="flex-1 bg-transparent text-[15px] text-[#24212B] outline-none placeholder:text-[#B4AEC0]"
        />
        <button
          onClick={onToggleListen}
          title="Talk instead"
          className="flex h-[38px] w-[38px] flex-shrink-0 items-center justify-center rounded-[10px] text-[#9B96A6] transition-colors hover:bg-[#F5F1FA] hover:text-[#6C63B5]"
        >
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
            <path d="M19 10v2a7 7 0 0 1-14 0v-2M12 19v4" />
          </svg>
        </button>
        <button
          onClick={onSend}
          title="Send"
          className="flex h-[38px] w-[38px] flex-shrink-0 items-center justify-center rounded-[10px] text-[#8B93B8] transition-colors hover:bg-[#F5F1FA] hover:text-[#6C63B5]"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M22 2 11 13" />
            <path d="M22 2 15 22l-4-9-9-4 20-7z" />
          </svg>
        </button>
      </div>

      <div className="mt-4 flex max-w-[640px] flex-wrap justify-center gap-2">
        {suggestions.map((s) => (
          <button
            key={s.title}
            onClick={() => onPickSuggestion(s.q)}
            className="rounded-full border border-[#EAE6EF] bg-white/80 px-3.5 py-2 text-[13px] text-[#6B6773] transition-colors hover:border-[#D9CFF2] hover:bg-[#F5F1FA]"
          >
            {s.title}
          </button>
        ))}
      </div>

      <button
        onClick={onUpload}
        className="mt-6 flex w-full max-w-[620px] items-center justify-center gap-2 rounded-2xl border-[1.5px] border-dashed border-[#D9CFF2] p-4 text-[13px] text-[#9B96A6] transition-colors hover:border-[#8F7FE8] hover:text-[#6C63B5]"
      >
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <path d="M17 8l-5-5-5 5M12 3v12" />
        </svg>
        <span>{uploadHint}</span>
      </button>
    </div>
  );
}
