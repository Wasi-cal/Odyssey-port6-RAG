'use client';

import { SparkleIcon } from './SparkleIcon';
import { MessageBubble } from './MessageBubble';
import type { Message } from '@/lib/types';

interface DockedThreadProps {
  onToggleListen: () => void;
  messages: Message[];
  citeSources: boolean;
  onOpenSource: (doc?: string) => void;
}

export function DockedThread({ onToggleListen, messages, citeSources, onOpenSource }: DockedThreadProps) {
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <button
        onClick={onToggleListen}
        title="Tap to talk"
        className="flex flex-shrink-0 items-center gap-3 border-b border-[#EAE6EF] bg-white/60 px-8 py-3 text-left backdrop-blur-sm transition-colors hover:bg-white"
      >
        <SparkleIcon size={18} className="text-[#24212B]" />
        <span className="text-[13px] font-semibold text-[#6B6773]">Tap to talk to Doc Assist</span>
      </button>

      <div className="flex flex-1 flex-col gap-4 overflow-y-auto px-8 py-6">
        {messages.map((m, i) => (
          <MessageBubble key={i} message={m} citeSources={citeSources} onOpenSource={onOpenSource} />
        ))}
      </div>
    </div>
  );
}
