# Handoff: HR Chatbot with Voice Agent

## Overview
An internal HR assistant chat UI: employees ask about leave, payroll, benefits, and conduct policies via text or a voice mode. Voice mode shows an animated "orb" that reacts to listening / thinking / speaking states. Assistant replies can include rich content: numbered steps, a policy-document card, a downloadable-file card, an "escalate to HR" card, and follow-up suggestion chips.

## About the Design Files
The file in this bundle (`HR Chatbot.dc.html`) is a **design reference built in HTML** — a working prototype showing intended layout, visual style, copy, and interaction/animation behavior. It is **not production code to copy in directly**. Your task is to **recreate this design in Next.js** (React + TypeScript), using idiomatic Next.js/React patterns — components, hooks, client/server component split — rather than porting the HTML's internal templating mechanics.

You can open the HTML file directly in a browser to see it live, or read its source for exact markup/values.

## Fidelity
**High-fidelity.** Colors, type, spacing, copy, and the canvas orb animation are final — recreate pixel-close using the values in this doc.

## Screens / Views
The whole thing is one page with state-driven views, not separate routes:

### 1. Welcome (empty) state
- Centered column, vertically/horizontally centered in the main content area.
- Sparkle icon (36×36), heading "Ask me about company policies" (30px/700/-0.01em), subtext "Leave, payroll, benefits, conduct — I've got the details, and I can talk it through too." (14.5px, color `#7d7690`, max-width 380px).
- Row of 3 pill "suggested prompt" buttons below (wraps, centered, gap 10px, max-width 520px).

### 2. Active chat
- Scrollable message list, 28px top / 12px bottom padding, messages padded 32px left/right, 22px gap between messages, fade-up-in animation (translateY 6px→0, opacity 0→1, 0.25s ease).
- User messages: right-aligned, label "YOU" above (10.5px/700/uppercase/letter-spacing .07em, color `#b7aec8`), bubble background `#f4eef2`, radius `16px 16px 4px 16px`, max-width 520px.
- Assistant messages: left-aligned, label "HR ASSISTANT" above, text bubble background `linear-gradient(135deg,#faf1f8,#f1eefb)`, 1px border `rgba(138,99,214,0.10)`, radius `16px 16px 16px 4px`, max-width 560px. Below the text bubble, an assistant message can carry ONE widget (see Components) plus optional follow-up chips.

### 3. Voice call overlay
- Full-viewport fixed overlay, `rgba(35,25,50,0.35)` tint + 6px backdrop blur.
- Centered panel (420px, transparent background — no card fill, content floats over the blurred backdrop): the orb, status text, transcript line, and two round controls (mute, end call).

### Sidebar (always visible, 272px fixed width)
- Frosted panel: `rgba(255,255,255,0.55)` + 16px backdrop blur, right border `1px solid rgba(30,20,45,0.07)`.
- Top → bottom: brand row (sparkle + "HR Assistant", 15px/700) → "New chat" button (white pill, plus icon) → scrollable middle section (Quick Links: 4 shortcut rows with doc icon + label + chevron; Recent: 3 history rows, active one tinted `rgba(138,99,214,0.10)` / text `#4a2f8a`) → pinned user profile row (avatar initials in gradient circle, name, role).

## Components

**Colors** (see Design Tokens below for the full list) — this doc calls out only component-specific values.

- **Sparkle icon**: single 4-point star path, fill `#6d4bb8`.
- **Buttons**:
  - Primary "Talk" button: gradient `linear-gradient(135deg,#9b7fe0,#e79bd0)`, white text/icon, 14px border-radius, 9px/15px padding.
  - Send button: circular 36px, solid `#6d4bb8`, white paper-plane icon.
  - New-chat / suggestion-pill / chip buttons: white fill, `1px solid rgba(30,20,45,0.08–0.12)` border, dark text, pill or 12px radius.
- **Rich content widgets** (inside assistant messages), all on white cards `1px solid rgba(30,20,45,0.08)`, `border-radius:14px`, subtle shadow `0 1px 3px rgba(30,20,45,0.04)`:
  - **Steps**: numbered circular badges (20px, tint `rgba(138,99,214,0.12)`, text `#6d4bb8`) + step text, stacked.
  - **Policy card**: doc icon in pink-tinted square (36px, `rgba(217,143,196,0.18)`), title + meta (e.g. "PDF · Updated Jan 2026"), chevron, whole row clickable.
  - **Attachment**: doc icon in purple-tinted square, filename + size, circular download-icon button on the right.
  - **Escalate**: headset icon in purple circle, "People Team" / "Usually replies within a few hours", solid purple "Contact HR team" button below.
  - **Follow-up chips**: row of pill buttons, clicking one sends it as the next user message.
- **Input bar**: white pill, `1px solid rgba(30,20,45,0.10)`, shadow `0 2px 10px rgba(30,20,45,0.05)`, text input + Talk button + circular send button.
- **Voice orb** (canvas-based, see Interactions & Behavior — Voice Orb Animation for full spec).

## Interactions & Behavior

- **Sending a message**: typing in the input and pressing Enter (or clicking send) pushes a user message, switches to chat view, and appends a canned assistant reply (in production this is where you call your HR-assistant API). Reply content is keyword-matched in the prototype (`leave`, `carry`, `apply`, `expense`, `payroll`, `conduct` → different widget types) — replace with real backend logic.
- **Sidebar shortcuts**: clicking a Quick Link sends its associated query as if typed.
- **Chips inside a reply**: clicking a chip sends its label as the next message.
- **New chat**: resets to the welcome view, clears messages.
- **Chat history**: clicking a Recent item loads that thread's messages (hardcoded demo transcripts in the prototype) and highlights the active row.
- **Talk button** opens the voice overlay.
- **Voice overlay state machine** (autoplay is the intended real behavior — a wired-up voice agent naturally moves through these states):
  1. `listening` — user is speaking; orb rim wobbles at moderate amplitude, particles jitter lightly.
  2. `thinking` — request is in flight; orb rim wobbles faster and larger, particles jitter more (this is the "fetching" state).
  3. `speaking` — response is being read aloud; orb settles to a slow, gentle rim wobble; particles hold still (only the boundary moves).
  - Closing the call while in `speaking` appends the exchange (user question + assistant answer) to the chat thread as regular messages; closing earlier discards it.
  - Mute toggle recolors the mic icon (purple → red) — wire to actual mic mute.
  - "End call" (red circular button) closes the overlay.
- **Voice Orb Animation** — implement as an HTML5 `<canvas>`, NOT CSS/SVG (needed for the pixelated look and per-frame procedural motion):
  - Render at **72×72 internal resolution**, displayed at **180×180 CSS px**, with `image-rendering: pixelated` and `ctx.imageSmoothingEnabled = false` — this is what gives the chunky/pixelated texture.
  - **Particles**: ~70 fixed points generated once per call (random angle `0–2π`, radius `2–26px` from center, size mostly 0.9px with ~15% at 1.6px, random twinkle phase). Each frame: draw as a filled `rgba(109,75,184, opacity)` square (`fillRect`), opacity oscillating via `sin(t·speed + phase)` between ~0.4–0.95. When not `speaking` ("agitated" = listening or thinking), add a small sinusoidal position jitter (amplitude 0.9px listening / 1.8px thinking) — particles are otherwise static (fixed polar position), only twinkling.
  - **Rim**: no filled sphere — the ball itself is transparent; only the particle field + rim are drawn. Draw the rim as **two** jagged stroked closed paths (18 segments each, low segment count is intentional — keeps the faceted/pixel look), radius ≈ `27 + amplitude·noise(angle,t)` using a two-term sine sum (`sin(freq·a + t·speed) + 0.5·sin(1.8·freq·a − 1.3·t·speed)`). Amplitude/frequency/speed by state: thinking `amp 6.5, freq 3.4, speed 1.7`; listening `amp 4, freq 2.4, speed 1.1`; speaking `amp 1.4, freq 2.4, speed 0.45`. Stroke color `rgba(109,75,184,0.7)` (inner pass) and `rgba(109,75,184,0.3)` (outer pass, offset +2px radius), 1px line width.
  - Loop via `requestAnimationFrame`, driven by elapsed time since the overlay opened; cancel on close/unmount.
- **Auto-scroll**: message list scrolls to bottom whenever a new message is appended.
- **Animations**: message bubbles fade+slide up on entry (`translateY(6px)→0`, `opacity 0→1`, 0.25s ease).

## State Management
Minimal state, easily modeled with React `useState`/`useReducer` in a client component:
- `view`: `'welcome' | 'chat'`
- `messages`: array of `{ id, role: 'user'|'assistant', text, widget?: {type, ...fields}, chips?: string[] }`
- `input`: current text field value
- `activeHistoryId`: which sidebar history row is selected (or null)
- `voiceOpen`: boolean
- `voiceState`: `'listening' | 'thinking' | 'speaking'`
- `voiceMuted`: boolean
- `transcript`: current live transcript line shown under the orb

Data fetching (production): replace the keyword-matched canned replies with a real call to your HR assistant/LLM backend; replace the hardcoded `HISTORY`/`CONVOS` with a real chat-history API; wire the voice state machine to your actual speech-to-text / LLM / text-to-speech pipeline (the `listening→thinking→speaking` transitions should be driven by real events: end-of-speech detected → response streaming → TTS playback start).

## Design Tokens

**Colors**
| Token | Hex / value | Use |
|---|---|---|
| Background gradient | `radial-gradient(ellipse 60% 55% at 18% 78%, rgba(250,205,232,.55), transparent 60%), radial-gradient(ellipse 55% 50% at 78% 26%, rgba(210,198,245,.55), transparent 60%), #fdfcff` | App background |
| Text primary | `#211f2b` | Body text |
| Text secondary | `#7d7690` / `#9a93a8` | Subtext, meta, timestamps |
| Text tertiary | `#b7aec8` | Message role labels, chevrons |
| Accent purple | `#6d4bb8` | Primary buttons, icons, links |
| Accent purple light | `#8a63d6` | Link default |
| Gradient accent | `#9b7fe0 → #e79bd0` | Talk button, avatar, orb particles conceptually |
| User bubble bg | `#f4eef2` | User chat bubble |
| Assistant bubble bg | `linear-gradient(135deg,#faf1f8,#f1eefb)` | Assistant text bubble |
| Card border | `rgba(30,20,45,0.08)` | White widget cards |
| Sidebar bg | `rgba(255,255,255,0.55)` + 16px blur | Sidebar |
| Danger | `#e0455a` | End-call button |
| Orb particle/rim | `#6d4bb8` at varying alpha | Voice orb |

**Typography**: Plus Jakarta Sans (Google Fonts), weights 400/500/600/700/800. Sizes used: 30px/700 (welcome heading), 15px/600 (brand, status text), 14.5px/400 (body, prompts), 13–13.5px/500–600 (buttons, titles), 11–12px (meta/labels), 10.5px/700 uppercase (role labels).

**Spacing/radius**: sidebar 272px fixed width; card radius 14px; pill radius 20px; button radius 9–14px; avatar/icon-button radius 50%; message bubble radius 16px with one 4px "tail" corner.

**Shadows**: `0 1px 2–4px rgba(30,20,45,0.04–0.08)` for resting cards/buttons; `0 2px 10px rgba(30,20,45,0.05)` for the input bar.

## Assets
No external image assets — all icons are inline SVGs (sparkle, plus, document, chevron-right, send/paper-plane, waveform bars, download, headset, mic, mic-slash/X for end-call). Recreate as an icon set (e.g. Lucide/Phosphor equivalents) or keep as inline SVGs — exact paths are in the HTML source if you want to match them precisely. Font is loaded from Google Fonts (`Plus Jakarta Sans`).

## Files
- `HR Chatbot.dc.html` — the full design reference. Contains the complete markup, inline styles, and the JS logic (message state machine, voice state machine, canvas orb drawing code) referenced throughout this doc. Read this file directly for exact values, copy text, and the orb's drawing math.
